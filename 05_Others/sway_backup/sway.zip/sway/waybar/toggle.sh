#!/usr/bin/env bash

if pgrep -x "waybar" > /dev/null; then
    pkill -x "waybar"
else
    waybar -c ~/.config/sway/waybar/config -s ~/.config/sway/waybar/style.css &
fi
